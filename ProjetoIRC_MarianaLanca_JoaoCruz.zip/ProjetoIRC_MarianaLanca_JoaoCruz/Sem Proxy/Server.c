#include <sys/socket.h>
#include <sys/types.h>
#include <resolv.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <sys/stat.h>

int n_clients_atual=0,chave_e=11;
char key[35] = "M|M|*fWXazrTvb!HB|ATm$9Sw*n*3D2mMx";

typedef struct send{
 struct sockaddr_in socket;
 int n_clients,sd_tcp;
}arg_thread;

// Thread created for each client
void *client(void *vargp){
    arg_thread arg =*((arg_thread*)vargp); // client fd
    int c_fd_tcp=arg.sd_tcp,n_client=arg.n_clients,c_fd_udp;
    char received_command[65535],protocol[100],encrypt[100],name[100],*token,path[100],number[100],path_file[100],packet_file[1000],receive[1],files[1000];
    int bytes = 0,counter=0;
    struct dirent *p_dir;
    int slen= sizeof(arg.socket);
    n_clients_atual++;
    FILE *file;
    DIR *dir;
    strcpy(path,"downloads/Cliente ");
    sprintf(number,"%d",n_client);
    strcat(path,number);//path for file "Download/Client X"
    strcat(path,"/");
    mkdir(path,S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH);
    if((c_fd_udp=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
        perror("Error creating sock");
        exit(-1);
    }
    write(c_fd_tcp, key, sizeof(key));
    while(1){
        //receive data from client
        memset(received_command,'\0',sizeof(received_command));
        bytes = read(c_fd_tcp, received_command, sizeof(received_command));
        if(bytes <0){
            perror("Error reading");
        }
        else {
            memset(path,0, sizeof(path));
            strcpy(path,"downloads/Cliente ");
            sprintf(number,"%d",n_client);
            strcat(path,number);//path for file "Download/Client X"
            strcat(path,"/");
            if(received_command[0]!='\0'){
                received_command[strlen(received_command)-1]='\0';    //udp
                if(strchr(received_command,' ')!=NULL && strncmp(received_command,"DOWNLOAD",8)==0) {//if it is a download
                    memset(name, 0, sizeof(name));
                    memset(encrypt, 0, sizeof(encrypt));
                    memset(protocol, 0, sizeof(protocol));
                    memset(name, 0, sizeof(name));
                    memset(path_file, 0, sizeof(path_file));
                    token = strtok(received_command, " ");
                    counter = 0;
                    while (token != NULL) {//vai por o protocol,encriptação e name do ficheiro
                        token = strtok(NULL, " ");
                        if (token != NULL) {
                            if (counter == 0) {
                                strcpy(protocol, token);
                                counter++;
                            } else if (counter == 1) {
                                strcpy(encrypt, token);
                                counter++;
                            } else if (counter == 2) {
                                strcpy(name, token);
                                counter++;
                            }
                        }
                    }
                    if (counter != 3) {
                        write(c_fd_tcp, "Wrong Command!", sizeof("Wrong command!"));
                        read(c_fd_tcp, receive, sizeof(receive));
                    }
                    else {
                        sprintf(path_file, "server_files/");
                        strcat(path_file, name);//Saber o path do ficheiro
                        file = fopen(path_file, "rb");
                        if (file != NULL) {
                            strcat(path, name);//poe o path para o name
                            write(c_fd_tcp, path, strlen(path));
                            read(c_fd_tcp, receive, sizeof(receive));
                            if (strcmp(protocol, "TCP") == 0) {
                                while (fread(packet_file, 1, sizeof(packet_file), file) !=
                                       0) {//envia o ficheiro pacote em pacote
                                    write(c_fd_tcp, packet_file, sizeof(packet_file));
                                    memset(packet_file, 0, sizeof(packet_file));
                                }
                                write(c_fd_tcp, packet_file, strlen(packet_file));
                                write(c_fd_tcp, "ENDOFFILE", sizeof("ENDOFFILE"));
                            } else if (strcmp(protocol, "UDP") == 0) {
                                while (fread(packet_file, 1, sizeof(packet_file), file) != 0) {
                                    sendto(c_fd_udp, packet_file, sizeof(packet_file), 0,
                                           (struct sockaddr *) &arg.socket,
                                           (socklen_t) slen);
                                    memset(packet_file, 0, sizeof(packet_file));
                                }
                                sendto(c_fd_udp, packet_file, sizeof(packet_file), 0, (struct sockaddr *) &arg.socket,
                                       (socklen_t) slen);
                                sendto(c_fd_udp, "ENDOFFILE", sizeof("ENDOFFILE"), 0, (struct sockaddr *) &arg.socket,
                                       (socklen_t) slen);
                            }
                            fclose(file);
                        } else {
                            write(c_fd_tcp, "Error opening file", sizeof("Error opening file"));
                        }
                    }
                }
                else if(strncmp(received_command,"QUIT",4)==0){
                    write(c_fd_tcp,"Quiting!",strlen("Quiting!"));
                    n_clients_atual--;
                    close(c_fd_tcp);
                    pthread_exit(NULL);
                }
                else if(strncmp(received_command,"LIST",4)==0){
                    dir = opendir("server_files");
                    //checka se a directoria foi criada ou não
                    if (dir == NULL){
                        perror("Wrong dir" );
                        exit(-1);
                    }
                    memset(files,0, sizeof(files));
                    while ((p_dir = readdir(dir)) != NULL) {
                        if (strcmp(p_dir->d_name, ".") != 0 && strcmp(p_dir->d_name, "..") != 0) {
                            strcat(files,p_dir->d_name);
                            strcat(files,"\n");
                        }
                    }
                    write(c_fd_tcp,files,strlen(files));
                }
                else {
                    write(c_fd_tcp, "Command does not exist", strlen("Command does not exist"));
                }
            }
            fflush(stdout);
        }
    }
    return NULL;
}

int main(int argc, char *argv[]){
    int client_fd,n_clients=0;
    char porto[100];
    int fd = 0,n_max_clients ;
    struct sockaddr_in server_addr_tcp;
    arg_thread send_thread;
    if(argc!=3){
        printf("Error! Wrong arguments, please insert: {port} {max clients number}");
        exit(-1);
    }
    n_max_clients=atoi(argv[2]);
    strcpy(porto, argv[1]);
    //Para quando o server é executado sem clients
    signal(SIGPIPE,SIG_IGN);
    printf("Server started\n");

    //tcp
    bzero((void *) &server_addr_tcp, sizeof(server_addr_tcp));//vai limpar a memoria
    server_addr_tcp.sin_family = AF_INET;
    server_addr_tcp.sin_port = htons(atoi(porto));
    inet_pton(AF_INET,"127.0.0.1",&server_addr_tcp.sin_addr);

    if ( (fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket");
        exit(-1);
    }
    if (bind(fd,(struct sockaddr*)&server_addr_tcp,sizeof(server_addr_tcp)) < 0) {
        perror("bind");
        exit(-1);
    }
    if(listen(fd, 100) < 0) {
        perror("listen");
        exit(-1);
    }

    //aceitar conexões
    while(1){
        // accept any incoming connection
        if(n_clients_atual<n_max_clients) {
            client_fd = accept(fd, (struct sockaddr *) NULL, NULL);
            n_clients++;
            // if true then client request is accpted
            if (client_fd > 0) {
                //multithreading variables
                printf("proxy connected\n");
                pthread_t tid;
                // pass client fd as a thread parameter
                send_thread.n_clients=n_clients;
                send_thread.socket=server_addr_tcp;
                send_thread.sd_tcp=client_fd,
                pthread_create(&tid, NULL, client,&send_thread);
            }
        }
        else{
            printf("Max number of clients");
        }
    }
    close(client_fd);
    return 0;
}