#include <sys/socket.h>
#include <string.h>
#include<unistd.h>
#include <stdio.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/time.h>

char key[35] = "M|M|*fWXazrTvb!HB|ATm$9Sw*n*3D2mMx";
int chave_d=11;


int main(int argc, char* argv[]) {
    //socket variables
    char proxy[100], port[100],server[100],protocol[100],file_rows[560],nome[100],received[1000],buffer[65535],path[1000],file_name[100];
    char* token;
    int sd_tcp,sd_udp,r,counter_bytes,i;
    long download_time;
    struct timeval beginning_time,end_time;
    FILE *f;
    struct sockaddr_in server_sd_tcp,server_sd_udp;
    int slen= sizeof(server_sd_tcp);
    signal(SIGPIPE,SIG_IGN);
    if(argc!=5){
        perror("Wrong arguments, please insert: {proxy address} {server address} {port} {protocol}");
        exit(-1);
    }
    strcpy(proxy, argv[1]);
    strcpy(port, argv[3]);
    strcpy(server,argv[2]);
    strcpy(protocol,argv[4]);

    //mudar isto para o proxy
    //socket tcp
    bzero((void *) &server_sd_tcp, sizeof(server_sd_tcp));
    server_sd_tcp.sin_family = AF_INET;
    inet_pton(AF_INET,server,&server_sd_tcp.sin_addr) ;
    server_sd_tcp.sin_port = htons((short)(atoi(port)));
    // connect ao proxy do porto especifico
    if((sd_tcp = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0){
        perror("Error in socket\n");
        exit(-1);
    }
    if( connect(sd_tcp,(struct sockaddr *)&server_sd_tcp,sizeof (server_sd_tcp)) < 0) {
        perror("Connect");
        exit(-1);
    }
    read(sd_tcp, buffer, sizeof(buffer));
    if(strncmp(buffer,key, sizeof(key))==0){
        while(1) {
            memset(buffer, 0, sizeof(buffer));
            memset(received, 0, sizeof(received));
            memset(file_rows, 0, sizeof(file_rows));
            memset(nome, 0, sizeof(nome));
            memset(path, 0, sizeof(path));
            printf("Write command:");
            fgets(buffer, sizeof(buffer), stdin);
            write(sd_tcp, buffer, strlen(buffer));
            if (strncmp(buffer, "DOWNLOAD", 8) == 0) {
                counter_bytes = 0;
                do {
                    r = read(sd_tcp, received, sizeof(received));
                } while (r < 0);
                write(sd_tcp, "*", sizeof("*"));
                if(strcmp(received,"Wrong Command!")!=0) {
                    f = fopen(received, "wb");
                    strcpy(path, received);
                    if (strcmp(received, "Error opening file") != 0) {
                        gettimeofday(&beginning_time, NULL);
                        if (strncmp(buffer + 9, "TCP", 3) == 0) {
                            do {
                                memset(received, 0, sizeof(received));
                                read(sd_tcp, received, sizeof(received));
                                if (strncmp(received, "ENDOFFILE", strlen("ENDOFFILE")) != 0) {
                                    if (strstr(path, ".txt") != NULL) {
                                        counter_bytes = strlen(received);
                                        fwrite(received, sizeof(char), strlen(received), f);
                                    } else {
                                        counter_bytes = sizeof(received);
                                        fwrite(received, sizeof(char), sizeof(received), f);
                                    }
                                }
                            } while (strncmp(received, "ENDOFFILE", strlen("ENDOFFILE")) != 0);
                            gettimeofday(&end_time, NULL);
                            token = strtok(buffer, " ");
                            token = strtok(NULL, " ");
                            token = strtok(NULL, " ");
                            token = strtok(NULL, " ");
                            strcpy(file_name, token);
                            download_time = end_time.tv_usec - beginning_time.tv_usec;
                            printf("Nome do ficheiro: %s", file_name);
                            printf("Nº total de bytes receiveds: %d\n", counter_bytes);
                            printf("Protoclo de transporte utilizado na transferencia: TCP\n");
                            printf("Tempo total para download do ficheiro: %li us\n", download_time);
                        } else if (strncmp(buffer + 9, "UDP", 3) == 0) {
                            bzero((void *) &server_sd_udp, sizeof(server_sd_udp));
                            //criar esta shit para o proxy TCP
                            server_sd_udp.sin_family = AF_INET;
                            inet_pton(AF_INET, server, &server_sd_udp.sin_addr);
                            server_sd_udp.sin_port = htons((short) (atoi(port)));
                            if ((sd_udp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
                                perror("Error creating socket");
                                exit(-1);
                            }
                            if (bind(sd_udp, (struct sockaddr *) &server_sd_udp, sizeof(server_sd_udp)) == -1) {
                                perror("Error in bind");
                                exit(-1);
                            }
                            do {
                                memset(received, 0, sizeof(received));
                                recvfrom(sd_udp, received, sizeof(received), 0, (struct sockaddr *) &server_sd_udp,
                                         (socklen_t * ) & slen);
                                if (strstr(path, ".txt") != NULL) {
                                    fwrite(received, sizeof(char), strlen(received), f);
                                } else {
                                    fwrite(received, sizeof(char), sizeof(received), f);
                                }
                            } while (strncmp(received, "ENDOFFILE", sizeof("ENDOFFILE")) != 0);
                            gettimeofday(&end_time, NULL);
                            token = strtok(buffer, " ");
                            token = strtok(NULL, " ");
                            token = strtok(NULL, " ");
                            token = strtok(NULL, " ");
                            strcpy(file_name, token);
                            download_time = end_time.tv_usec - beginning_time.tv_usec;
                            printf("Nome do ficheiro: %s", file_name);
                            printf("Nº total de bytes receiveds: %d\n", counter_bytes);
                            printf("Protoclo de transporte utilizado na transferencia: UDP\n");
                            printf("Tempo total para download do ficheiro: %li\n", download_time);
                            close(sd_udp);
                        } else {
                            read(sd_tcp, file_rows, sizeof(file_rows));
                            printf("%s\n", file_rows);
                        }
                        fflush(f);
                        fclose(f);
                    }
                    else{
                        printf("File not found\n");
                    }
                }
                else{
                    printf("%s\n",received);
                }
            } else if ((strncmp(buffer, "QUIT", 4) == 0)) {
                read(sd_tcp, received, sizeof(received));
                printf("%s\n", received);
                exit(-1);
            } else {
                read(sd_tcp, received, sizeof(received));
                printf("%s\n", received);
            }
        }
        close(sd_tcp);
        return 0;
    }
    else{
        printf("Could not access Server!");
    }
}
