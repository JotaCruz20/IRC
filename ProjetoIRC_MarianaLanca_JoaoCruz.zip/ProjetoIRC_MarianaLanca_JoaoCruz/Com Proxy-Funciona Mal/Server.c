#include <sys/socket.h>
#include <sys/types.h>
#include <resolv.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <sys/stat.h>

int n_clients_atual=0;

typedef struct send{
 struct sockaddr_in socket;
 int n_clients,sd_tcp;
}arg_thread;

// Thread criada para cada cliente
void *client(void *vargp){
    arg_thread arg =*((arg_thread*)vargp); // client fd
    int c_fd_tcp=arg.sd_tcp,n_client=arg.n_clients,c_fd_udp;
    char comando_recebido[65535],protocolo[100],encrypt[100],nome[100],*token,path[100],number[100],path_file[100],packet_file[1000],receive[1],files[1000];
    int bytes = 0,counter=0;
    struct dirent *p_dir;
    int slen= sizeof(arg.socket);
    n_clients_atual++;
    FILE *file;
    DIR *dir;
    strcpy(path,"downloads/Cliente ");
    sprintf(number,"%d",n_client);
    strcat(path,number);//path para o ficheiro "Download/Client X"
    strcat(path,"/");
    mkdir(path,S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IWGRP | S_IXGRP | S_IROTH | S_IWOTH | S_IXOTH);
    if((c_fd_udp=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
        perror("Erro na criação do socket");
        exit(-1);
    }
    while(1){
        //receive data from client
        memset(comando_recebido,'\0',sizeof(comando_recebido));
        bytes = read(c_fd_tcp, comando_recebido, sizeof(comando_recebido));
        if(bytes <0){
            perror("Error on read");
        }
        else {
            memset(path,0, sizeof(path));
            strcpy(path,"downloads/Cliente ");
            sprintf(number,"%d",n_client);
            strcat(path,number);//path para o ficheiro "Download/Client X"
            strcat(path,"/");
            if(comando_recebido[0]!='\0'){
                comando_recebido[strlen(comando_recebido)-1]='\0';    //udp
                if(strchr(comando_recebido,' ')!=NULL && strncmp(comando_recebido,"DOWNLOAD",8)==0) {//se for download
                    memset(nome, 0, sizeof(nome));
                    memset(encrypt, 0, sizeof(encrypt));
                    memset(protocolo, 0, sizeof(protocolo));
                    memset(nome, 0, sizeof(nome));
                    memset(path_file, 0, sizeof(path_file));
                    token = strtok(comando_recebido, " ");
                    counter=0;
                    while (token != NULL) {//vai por o protocolo,encriptação e nome do ficheiro
                        token = strtok(NULL, " ");
                        if (counter == 0) {
                            strcpy(protocolo, token);
                            counter++;
                        } else if (counter == 1) {
                            strcpy(encrypt, token);
                            counter++;
                        } else if (counter == 2) {
                            strcpy(nome, token);
                            counter++;
                        }
                    }
                    sprintf(path_file, "server_files/");
                    strcat(path_file, nome);//Saber o path do ficheiro
                    file = fopen(path_file, "rb");
                    if (file != NULL) {
                        strcat(path, nome);//poe o path para o nome
                        write(c_fd_tcp, path, strlen(path));
                        read(c_fd_tcp,receive, sizeof(receive));
                        if (strcmp(protocolo, "TCP")==0) {
                            while(fread(packet_file,1, sizeof(packet_file),file)!=0){//envia o ficheiro pacote em pacote
                                write(c_fd_tcp,packet_file, sizeof(packet_file));
                                memset(packet_file,0, sizeof(packet_file));
                            }
                            write(c_fd_tcp,packet_file,strlen(packet_file));
                            write(c_fd_tcp,"ENDOFFILE", sizeof("ENDOFFILE"));
                        }
                        else if (strcmp(protocolo, "UDP")==0) {
                            while(fread(packet_file,1, sizeof(packet_file),file)!=0){
                                sendto(c_fd_udp, packet_file, sizeof(packet_file), 0, (struct sockaddr *) &arg.socket, (socklen_t)slen);
                                memset(packet_file,0, sizeof(packet_file));
                            }
                            sendto(c_fd_udp, packet_file, sizeof(packet_file), 0, (struct sockaddr *) &arg.socket, (socklen_t)slen);
                            sendto(c_fd_udp, "ENDOFFILE", sizeof("ENDOFFILE"), 0, (struct sockaddr *) &arg.socket, (socklen_t)slen);
                        }
                        fclose(file);
                    }
                    else{
                        write(c_fd_tcp,"Error a Abrir Ficheiro",strlen("Error a Abrir Ficheiro"));
                    }
                }
                else if(strncmp(comando_recebido,"QUIT",4)==0){
                    write(c_fd_tcp,"Saindo!",strlen("Saindo!"));
                    n_clients_atual--;
                    pthread_exit(NULL);
                }
                else if(strncmp(comando_recebido,"LIST",4)==0){
                    dir = opendir("server_files");
                    //checka se a directoria foi criada ou não
                    if (dir == NULL){
                        perror("Diretoria Errada" );
                        exit(-1);
                    }
                    memset(files,0, sizeof(files));
                    while ((p_dir = readdir(dir)) != NULL) {
                        if (strcmp(p_dir->d_name, ".") != 0 && strcmp(p_dir->d_name, "..") != 0) {
                            strcat(files,p_dir->d_name);
                            strcat(files,"\n");
                        }
                    }
                    write(c_fd_tcp,files,strlen(files));
                }
                else {
                    write(c_fd_tcp, "Comando não existe", strlen("Comando não existe"));
                }
            }
            fflush(stdout);
        }
    }
    return NULL;
}

int main(int argc, char *argv[]){
    int client_fd,n_clients=0;
    char porto[100];
    int fd = 0,n_max_clients ;
    struct sockaddr_in server_addr_tcp;
    arg_thread send_thread;
    if(argc!=3){
        printf("Erro! Não tem os argumentos de entrada corretos, por favor ponha: {porto} {numero máximo de clientes}");
        exit(-1);
    }
    n_max_clients=atoi(argv[2]);
    strcpy(porto, argv[1]);
    //Para quando o server é executado sem clients
    signal(SIGPIPE,SIG_IGN);
    printf("Server started\n");

    //tcp
    bzero((void *) &server_addr_tcp, sizeof(server_addr_tcp));//vai limpar a memoria
    server_addr_tcp.sin_family = AF_INET;
    server_addr_tcp.sin_port = htons(atoi(porto));
    inet_pton(AF_INET,"127.0.0.1",&server_addr_tcp.sin_addr);

    if ( (fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("na funcao socket");
        exit(-1);
    }
    if (bind(fd,(struct sockaddr*)&server_addr_tcp,sizeof(server_addr_tcp)) < 0) {
        perror("na funcao bind");
        exit(-1);
    }
    if(listen(fd, 100) < 0) {
        perror("na funcao listen");
        exit(-1);
    }

    //aceitar conexões
    while(1){
        // accept any incoming connection
        if(n_clients_atual<n_max_clients) {
            client_fd = accept(fd, (struct sockaddr *) NULL, NULL);
            n_clients++;
            // if true then client request is accpted
            if (client_fd > 0) {
                //multithreading variables
                printf("proxy connected\n");
                pthread_t tid;
                // pass client fd as a thread parameter
                send_thread.n_clients=n_clients;
                send_thread.socket=server_addr_tcp;
                send_thread.sd_tcp=client_fd,
                pthread_create(&tid, NULL, client,&send_thread);
            }
        }
        else{
            printf("Numero maximo de Clients Atingido");
        }
    }
    close(client_fd);
    return 0;
}