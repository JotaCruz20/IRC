#include <sys/socket.h>  
#include <sys/types.h>  
#include <resolv.h>  
#include <string.h>  
#include <stdlib.h>  
#include<netdb.h> 
#include <pthread.h>  
#include<unistd.h>  
#include<arpa/inet.h>  
#include <stdbool.h>

typedef struct{ 
    char server_ip[100],client_ip[100];  
    char server_port[100],client_port[100]; 
    int client_fd, server_fd;
    char *protocol;
    //struct sockaddr_in server;

}connection_data;

typedef struct{
    connection_data data;
    bool ocuppied;
}array_data;

int loss_value = 0;
bool save_value = true;

array_data thread_array_data[20]; //fazer malloc
pthread_t thread_array[20]; //fazer malloc

pthread_mutex_t lock_mutex = PTHREAD_MUTEX_INITIALIZER; 

//Refazer
 // A thread for each client request 
void *socket_thread(void *arg){
    array_data *info = (array_data *)arg;  //server data casting 
    struct sockaddr_in server_addr;
    char buffer[1248], *aux[5], protocol[3]; 
    char packet_file[1000];
    int i=0;

    FILE *file;
    char file_name[10];
    int server_fd;

    //conecta e só quando for para enviar e que faz a distinção
    if((server_fd= socket(AF_INET,SOCK_STREAM,0))<0){
        perror("server socket not created: ");  
        pthread_exit(NULL);    
        return NULL; 
    }
    
    bzero((void *) &server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr(info->data.server_ip); 
    server_addr.sin_port = htons((short)atoi(info->data.server_port)); 

    if((connect(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)))<0)  {  
        perror("Could not connect to server: ");  
        pthread_exit(NULL);    
        return NULL; 
    }  
    printf("server socket connected\n");  

    memset(buffer,0,sizeof(buffer));
    read(info->data.client_fd,buffer,sizeof(buffer)-1);//Receives server message with data

    aux[0]=strtok(buffer," "); //Verify server command
    i++;
    while(aux!=NULL){
        aux[i] = strtok(NULL," ");
        i++;
    }
    strcpy(protocol,aux[3]);
    strcpy(info->data.protocol,protocol);

    //Verify Client command
    if(strcmp(aux[0],"DOWNLOAD") && i==4){
        if(save_value){
            sprintf(file_name,"%d.txt",info->data.client_fd);
            file = fopen(file_name,"w");
        }

        if(strcmp(protocol,"UDP")==0){   
            printf("--CLIENT--\nIP address: %d\nPort: %d\nProtocol: UDP\n\n",0,0);
            while(1){
                memset(&buffer,'\0',sizeof(buffer));
                pthread_mutex_lock(&lock_mutex);
                            

                if(recvfrom(info->data.client_fd,buffer,sizeof(buffer)-1,0,(struct sockaddr *)&server_addr,(socklen_t *)sizeof(server_addr))>0){//proxy received message
                    //send data to main server
                    sendto(server_fd,buffer,sizeof(buffer)+1,0,(struct sockaddr *)&server_addr,(socklen_t)sizeof(server_addr));
                }
                //receive package from server and send it to client
                if(save_value){
                    sprintf(file_name,"%d.txt",info->data.client_fd);
                    file = fopen(file_name,"w");
                }
                memset(&packet_file,'\0',sizeof(packet_file));
                recvfrom(info->data.client_fd,packet_file,sizeof(packet_file)-1,0,(struct sockaddr *)&server_addr,(socklen_t *)sizeof(server_addr));
                while(strcmp(packet_file,"ENDOFFILE")!=0){
                    if(rand()% 101>=loss_value){
                        memset(&packet_file,0, sizeof(packet_file));
                        sendto(info->data.client_fd,packet_file,sizeof(packet_file)+1,0,(struct sockaddr *)&server_addr,(socklen_t)sizeof(server_addr));
                        if(save_value){
                            fwrite(packet_file, sizeof(char), sizeof(packet_file), file);
                            }                        
                    }
                }               
            }
        }
        else if(strcmp(protocol,"TCP")==0){
            while(1){
                memset(&buffer,'\0',sizeof(buffer));
                pthread_mutex_lock(&lock_mutex);
                if(read(info->data.client_fd,buffer,sizeof(buffer))>0){ //proxy received message
                    //send data to main server
                    write(server_fd,buffer,sizeof(buffer));
                }
                //receive package from server and send it to client
                memset(&packet_file,'\0',sizeof(buffer));
                read(server_fd,packet_file,sizeof(buffer)-1);
                while(strcmp(packet_file,"ENDOFFILE")!=0){
                    write(info->data.client_fd,packet_file,sizeof(packet_file)+1);
                    memset(&packet_file,0, sizeof(packet_file));
                    if(save_value){
                        fwrite(packet_file, sizeof(char), sizeof(packet_file), file);
                    }
                }
            }
        }
    }
    else if(strcmp(aux[0],"QUIT")==0){
        info->ocuppied = false;
        write(info->data.server_fd,aux[0],sizeof(aux[0]));
        close(info->data.client_fd);
        pthread_exit(NULL);
        return NULL;
    }
    else{
        printf("Wrong Command\n"); 
    }
}

void* command_listener(){ //Thread to listen to the commands that are inserted in the console
    char str[1024], *ptr[5]; int size=0;
    while(1){
        if(fgets (str, 60, stdin)!=NULL && strlen(str)>1) { //dá segfault se não se der nada
            size=0;
            str[strlen(str)-1]= '\0';

            ptr[0]= strtok(str," ");
            size++;
            while((ptr[size]=strtok(NULL," "))!=NULL){
                size++;
            }


            if(strcmp(ptr[0],"LOSSES")==0){ //changes loss value
                if(size==2){
                    loss_value = atoi(ptr[1]);
                    printf("Loss value set to %d\n",loss_value);
                }
                else{
                    printf("Invalid command\n");
                }
            }
            else if(strcmp(ptr[0],"SHOW")==0 && size==1){  //print info regarding the current connections
                for(int i=0;i<sizeof(thread_array_data)/sizeof(array_data);i++){
                    if(thread_array_data[i].ocuppied){
                        printf("CONNECTION CLIENT-SERVER\n");
                        printf("\tSOURCE ADDRESS %s\n",thread_array_data[i].data.server_ip);
                        printf("\tSOURCE PORT %s\n",thread_array_data[i].data.server_port);
                        printf("DESTINATION ADDRESS: %s\n",thread_array_data[i].data.client_ip);
                        printf("DESTINATION PORT: %s\n",thread_array_data[i].data.client_port);
                        printf("PROTOCOL: %s\n", thread_array_data[i].data.protocol);
                    }
                }  
            }
            else if(strcmp(ptr[0],"SAVE")==0){
                if(size==1){save_value = !save_value;
                printf("SAVE set to %d\n",save_value);}
            }
            else{
                printf("Invalid command\n");
            }
        }      
    }
    pthread_exit(NULL);
    return NULL;
}

//COMPLETO (ACHO)
int main(int argc,char *argv[]){ //ircproxy <port>
    pthread_t command_thread; 
    char server_port[100];  //server
    char proxy_port[100];
    int proxy_fd =0, client_fd=0, server_fd; //socket variables  
    struct sockaddr_in proxy_addr, server_addr, client_addr;
    struct hostent *hostPtr;
    char message[100];


    if (argc != 3 || strcmp(argv[1],"ircproxy")!=0) { //receives proxy port
    	printf("ircproxy <port>\n");
    	exit(-1);
    }

    strcpy(proxy_port,argv[2]); //stores proxy port
    //strcpy(server_ip,"127.0.0.1"); //stores server ip

    
    printf("Proxy Port: %s\n",proxy_port);

    //create thread to receive commands
    if(pthread_create(&command_thread,NULL,command_listener,NULL)!=0){
        perror("Error creating thread: ");
        exit(1);
    }

    if((proxy_fd = socket(AF_INET,SOCK_STREAM,0)) < 0 ){perror("Failed to create socket: ");}// create a socket
    
    if ((hostPtr = gethostbyname("127.0.0.1")) == 0)
    	perror("Culd not obtain address: ");
    
    printf("Proxy socket created\n");
    
    bzero((void *) &proxy_addr, sizeof(proxy_addr));  ////clear struct where data is going to be stored
    proxy_addr.sin_family = AF_INET;  
    proxy_addr.sin_port = htons(atoi(proxy_port));  
    proxy_addr.sin_addr.s_addr = INADDR_ANY;  

    if (bind(proxy_fd,(struct sockaddr*)&proxy_addr,sizeof(proxy_addr)) < 0){perror("Failed to bind a socket: ");}//bind the socket

    //get ready to listen to clients
    if((listen(proxy_fd, SOMAXCONN)) < 0)  {perror("Failed to listen: ");}
    size_t client_addr_size = sizeof(client_addr);


    while(1){
            
        client_fd = accept(proxy_fd, (struct sockaddr *)&client_addr ,(socklen_t *)&client_addr_size);  //é necessário passar para o client_addr tendo em conta que esses dados não serão utilizados?

        if(client_fd>0){

            server_fd = connect(server_fd,((struct sockaddr *)&server_addr),sizeof (server_addr));
            read(server_fd,message,sizeof(message)-1); //Receives server message with its port
            printf("Received \"%s\" command\n",message);
                
            strcpy(server_port, message); //Receives and stores server port

            for(int i=0;i<sizeof(thread_array_data)/sizeof(array_data);i++){
                if(thread_array_data->ocuppied!=true){
                    printf("Client connected\n");
                    //Stores server data in its struct 
                    //thread_array_data[i].data = malloc (sizeof(connection_data));
                    thread_array_data[i].data.client_fd = client_fd;
                    inet_ntop(AF_INET,&server_addr,thread_array_data[i].data.server_ip,INET_ADDRSTRLEN);
                    //strcpy(thread_array_data[i].data.server_ip,server_ip);
                    strcpy(thread_array_data[i].data.server_port,server_port);
                    inet_ntop(AF_INET,&client_addr,thread_array_data[i].data.client_ip,INET_ADDRSTRLEN);
                    sprintf(thread_array_data[i].data.client_port,"%d",client_addr.sin_port);
                    thread_array_data[i].data.server_fd = server_fd;
                    //thread_array_data[i].data.server=server_addr;

                    if(pthread_create(&thread_array[i],NULL,socket_thread,&thread_array_data[i])!=0){
                        perror("Error in creating thread: ");
                        exit(0);
                    }
                }
            }

            
        }
    }
    return 0;
}