#include <sys/socket.h>
#include <string.h>
#include<unistd.h>
#include <stdio.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <signal.h>
#include <arpa/inet.h>
#include <sys/time.h>


int main(int argc, char* argv[]) {
    //socket variables
    char proxy[100], port[100],server[100],protocolo[100],linhas_ficheiro[560],nome[100],recebido[1000],buffer[65535],path[1000],file_name[100];
    char* token;
    int sd_tcp,sd_udp,r,counter_bytes;
    long tempo_download;
    struct timeval tempo_inicial,tempo_final;
    FILE *f;
    struct sockaddr_in proxy_sd,server_sd,proxy_sd_udp;
    int slen= sizeof(proxy_sd);
    signal(SIGPIPE,SIG_IGN);
    if(argc!=5){
        perror("Inicie o programa com os seguintes parametros: {endereço do proxy} {endereço do servidor} {porto} {protocolo}");
        exit(-1);
    }
    strcpy(proxy, argv[1]);
    strcpy(port, argv[3]);
    strcpy(server,argv[2]);
    strcpy(protocolo,argv[4]);

    //proxy
    bzero((void *) &proxy_sd, sizeof(proxy_sd));
    //criar esta shit para o proxy TCP
    proxy_sd.sin_family = AF_INET;
    inet_pton(AF_INET,server,&proxy_sd.sin_addr) ;
    proxy_sd.sin_port = htons((short)(atoi(proxy)));

    // connect ao proxy do porto especifico
    if((sd_tcp = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0){
        perror("Erro no socket\n");
        exit(-1);
    }
    if( connect(sd_tcp,(struct sockaddr *)&proxy_sd,sizeof (proxy_sd)) < 0) {
        perror("Connect");
        exit(-1);
    }
    //server
    server_sd.sin_family = AF_INET;
    inet_pton(AF_INET,server,&proxy_sd.sin_addr) ;
    server_sd.sin_port = htons((short)(atoi(port)));
    write(sd_tcp,&server_sd ,sizeof(server_sd));
    /******************************************************************************************************************/
    while(1){
        memset(buffer,0,sizeof(buffer));
        memset(recebido,0,sizeof(recebido));
        memset(linhas_ficheiro,0,sizeof(linhas_ficheiro));
        memset(nome,0,sizeof(nome));
        memset(path,0, sizeof(path));
        printf("Escrever comando:");
        fgets(buffer, sizeof(buffer), stdin);
        //write(sd_tcp, buffer, strlen(buffer));
        if(strncmp(buffer,"DOWNLOAD",8)==0){
            counter_bytes=0;
            do {
                r=read(sd_tcp, recebido, sizeof(recebido));
            }while(r<0);
            write(sd_tcp,"*", sizeof("*"));
            f=fopen(recebido, "wb");
            strcpy(path,recebido);
            if (strncmp(recebido, "Error a Abrir Ficheiro", strlen("Error a Abrir Ficheiro")) != 0) {
                gettimeofday(&tempo_inicial,NULL);
                if (strncmp(buffer + 9, "TCP", 3) == 0){
                    do{
                        memset(recebido, 0, sizeof(recebido));
                        read(sd_tcp, recebido, sizeof(recebido));
                        if (strncmp(recebido, "ENDOFFILE", strlen("ENDOFFILE")) != 0) {
                            if(strstr(path,".txt")!=NULL) {
                                counter_bytes=strlen(recebido);
                                fwrite(recebido, sizeof(char), strlen(recebido), f);
                            }
                            else{
                                counter_bytes= sizeof(recebido);
                                fwrite(recebido, sizeof(char), sizeof(recebido), f);
                            }
                        }
                    }while (strncmp(recebido, "ENDOFFILE", strlen("ENDOFFILE")) != 0);
                    gettimeofday(&tempo_final,NULL);
                    token=strtok(buffer," ");
                    token=strtok(NULL," ");
                    token=strtok(NULL," ");
                    token=strtok(NULL," ");
                    strcpy(file_name,token);
                    tempo_download=tempo_final.tv_usec-tempo_inicial.tv_usec;
                    printf("Nome do ficheiro: %s",file_name);
                    printf("Nº total de bytes recebidos: %d\n",counter_bytes);
                    printf("Protoclo de transporte utilizado na transferencia: TCP\n");
                    printf("Tempo total para download do ficheiro: %li us\n",tempo_download);
                }
                else if(strncmp(buffer+9,"UDP",3)==0) {
                    bzero((void *) &proxy_sd_udp, sizeof(proxy_sd_udp));
                    //criar esta shit para o proxy TCP
                    proxy_sd_udp.sin_family = AF_INET;
                    inet_pton(AF_INET,server,&proxy_sd_udp.sin_addr) ;
                    proxy_sd_udp.sin_port = htons((short)(atoi(proxy)));
                    if((sd_udp=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
                        perror("Erro na criação do socket");
                        exit(-1);
                    }
                    if(bind(sd_udp,(struct sockaddr*)&proxy_sd_udp, sizeof(proxy_sd_udp)) == -1){
                        perror("Erro no bind");
                        exit(-1);
                    }
                    do{
                        memset(recebido, 0, sizeof(recebido));
                        recvfrom(sd_udp, recebido, sizeof(recebido), 0, (struct sockaddr *) &proxy_sd_udp, (socklen_t *) &slen);
                        if(strstr(path,".txt")!=NULL) {
                            fwrite(recebido, sizeof(char), strlen(recebido), f);
                        }
                        else{
                            fwrite(recebido, sizeof(char), sizeof(recebido), f);
                        }
                    }while (strncmp(recebido, "ENDOFFILE", sizeof("ENDOFFILE")) != 0);
                    gettimeofday(&tempo_final,NULL);
                    token=strtok(buffer," ");
                    token=strtok(NULL," ");
                    token=strtok(NULL," ");
                    token=strtok(NULL," ");
                    strcpy(file_name,token);
                    tempo_download=tempo_final.tv_usec-tempo_inicial.tv_usec;
                    printf("Nome do ficheiro: %s",file_name);
                    printf("Nº total de bytes recebidos: %d\n",counter_bytes);
                    printf("Protoclo de transporte utilizado na transferencia: UDP\n");
                    printf("Tempo total para download do ficheiro: %li\n",tempo_download);
                    close(sd_udp);
                }
                else {
                    read(sd_tcp, linhas_ficheiro, sizeof(linhas_ficheiro));
                    printf("%s\n",linhas_ficheiro);
                }
                fflush(f);
                fclose(f);
            }
        }
        else if((strncmp(buffer,"QUIT",4)==0)){
            write(sd_tcp, buffer, strlen(buffer));
            read(sd_tcp,recebido,sizeof(recebido));
            printf("%s\n",recebido);
        }
        else{
            read(sd_tcp,recebido,sizeof(recebido));
            printf("%s\n",recebido);
        }
    };
    close(sd_tcp);
    return 0;
}